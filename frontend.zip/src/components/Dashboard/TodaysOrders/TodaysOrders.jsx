// src/components/Dashboard/TodaysOrders/TodaysOrders.jsx
import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import OrdersTableRow from "./OrdersTableRow";
import SampleCollectionModal from "../../LabOrders/SampleCollectionModal";
import { getTodaysOrdersApi } from "../../../api/api";
import CancelledOrderModal from "../../LabOrders/CancelledOrderModal";

function capitalize(str) {
  return str ? str.charAt(0).toUpperCase() + str.slice(1) : str;
}

function statusLabel(status) {
  if (status === "sample_collected") return "Sample Collected";
  return capitalize(status);
}

const ABBREVIATED_TITLES = ["mr", "mrs", "ms", "dr", "prof"];

function formatTitle(title) {
  if (!title) return "";
  const t = title.trim();
  if (ABBREVIATED_TITLES.includes(t.toLowerCase().replace(/\.$/, ""))) {
    return t.replace(/\.$/, "") + ".";
  }
  return t;
}

function mapOrder(o) {
  return {
    order: o.order_no,
    patient: [formatTitle(o.patient?.title), o.patient?.first_name, o.patient?.last_name]
      .filter(Boolean)
      .join(" "),
    regNo: o.patient?.patient_number || "",
    tests: o.items_count ?? o.items?.length ?? 0,
    testNames: (o.items || []).map((item) => item.lab_test?.name).filter(Boolean),
    status: statusLabel(o.status),
    rawStatus: o.status,
    time: o.ordered_at
      ? new Date(o.ordered_at).toLocaleTimeString("en-US", {
          hour: "numeric", minute: "2-digit",
        })
      : "",
  };
}

export default function TodaysOrders() {
  const navigate = useNavigate();
  const [orders, setOrders] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [modalOrder, setModalOrder] = useState(null);
  const [cancelledOrder, setCancelledOrder] = useState(null);

  async function loadOrders() {
    try {
      const res = await getTodaysOrdersApi();
      setOrders((res.data || []).map(mapOrder));
    } catch {
      setOrders([]);
    }
  }

  useEffect(() => {
    let cancelled = false;

    getTodaysOrdersApi()
      .then((res) => {
        if (!cancelled) setOrders((res.data || []).map(mapOrder));
      })
      .catch(() => {
        if (!cancelled) setOrders([]);
      })
      .finally(() => {
        if (!cancelled) setIsLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, []);

  function handleOpenOrder(order) {
    if (order.rawStatus === "pending") {
      setModalOrder(order);
    } else if (order.rawStatus === "cancelled") {
      setCancelledOrder({
        orderId: order.order,
        patient: order.patient,
        regNo: order.regNo,
        tests: order.tests,
      });
    } else {
      navigate(`/lab-orders/${order.order}`);
    }
  }

  function handleSampleCollected(orderId) {
    setModalOrder(null);
    navigate(`/lab-orders/${orderId}`, {
      state: { justCollected: { orderId, patientName: modalOrder?.patient } },
    });
  }

  // Called by the popup after the order was cancelled successfully.
  // Close the popup and reload the list so the order's status updates.
  function handleOrderCancelled() {
    setModalOrder(null);
    loadOrders();
  }

  if (isLoading || orders.length === 0) {
    return null;
  }

  return (
    <div className="bg-white rounded-xl p-5 shadow-[0_1px_3px_rgba(0,0,0,0.06)]">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold text-sm text-gray-900">Today's Orders</h3>
        <Link to="/lab-orders" className="text-sm text-teal-600 font-medium hover:underline">
          View all orders →
        </Link>
      </div>

      <table className="w-full">
        <thead>
          <tr className="text-left border-b border-gray-100">
            <th className="pb-2 text-xs font-medium text-gray-400 tracking-wide">ORDER</th>
            <th className="pb-2 text-xs font-medium text-gray-400 tracking-wide">PATIENT</th>
            <th className="pb-2 text-xs font-medium text-gray-400 tracking-wide">TESTS</th>
            <th className="pb-2 text-xs font-medium text-gray-400 tracking-wide">STATUS</th>
            <th className="pb-2 text-xs font-medium text-gray-400 tracking-wide">TIME</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {orders.map((o) => (
            <OrdersTableRow key={o.order} {...o} onOpen={handleOpenOrder} />
          ))}
        </tbody>
      </table>

      {modalOrder && (
        <SampleCollectionModal
          order={{
            orderId: modalOrder.order,
            patient: modalOrder.patient,
            regNo: modalOrder.regNo,
            tests: modalOrder.tests,
            testNames: modalOrder.testNames,
          }}
          onClose={() => setModalOrder(null)}
          onConfirmed={handleSampleCollected}
          onCancelled={handleOrderCancelled}
        />
      )}

      {cancelledOrder && (
        <CancelledOrderModal
          order={cancelledOrder}
          onClose={() => setCancelledOrder(null)}
        />
      )}
    </div>
  );
}