// src/components/FollowUps/FollowUpsTable/FollowUpCard.jsx
import StatusBadge from "../../Dashboard/TodaysOrders/StatusBadge";

import { nameWithTitle } from "../../Patients/patientTitles";

export default function FollowUpCard({ title, patient, test, due, status, onView, onViewPatient }) {
  return (
    <div className="border border-gray-100 rounded-lg p-4 space-y-2">
      <div className="flex items-center justify-between">
        <button
          onClick={onViewPatient}
          className="text-sm font-semibold text-gray-900 hover:text-teal-600 cursor-pointer"
        >
          {nameWithTitle(title, patient)}
        </button>
        <StatusBadge status={status} />
      </div>
      <p className="text-sm text-gray-700">{test}</p>
      <div className="flex items-center justify-between">
        <p className="text-xs text-gray-400">Due {due}</p>
        <button
          onClick={onView}
          className="text-xs text-teal-600 font-medium cursor-pointer"
        >
          View
        </button>
      </div>
    </div>
  );
}