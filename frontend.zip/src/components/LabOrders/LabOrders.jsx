// src/components/LabOrders/LabOrders.jsx
import { useState, useEffect, useMemo } from "react";
import { useLocation, useNavigate, useSearchParams } from "react-router-dom";
import { X } from "lucide-react";
import LabOrdersHeader from "./LabOrdersHeader";
import LabOrdersFilters from "./LabOrdersFilters";
import LabOrdersTable from "./LabOrdersTable/LabOrdersTable";
import LabOrderCard from "./LabOrdersTable/LabOrderCard";
import SampleCollectionModal from "./SampleCollectionModal";
import Toast from "../common/Toast/Toast";
import { useToast } from "../common/Toast/useToast";
import { getOrdersApi, getGstSettingsApi } from "../../api/api";
import { calcBillTotals } from "../../utils/orderPricing";
import CancelledOrderModal from "./CancelledOrderModal";

const PER_PAGE = 9;

function capitalize(str) {
  return str ? str.charAt(0).toUpperCase() + str.slice(1) : str;
}

function statusLabel(status) {
  if (status === "sample_collected") return "Sample Collected";
  return capitalize(status);
}

// Converts a filter-tab label into the raw status value the backend expects.
// "All" / "Pending" / "Completed" already match; only "Sample Collected"
// needs converting, since the DB stores it as "sample_collected".
function tabToStatus(tab) {
  if (tab === "Sample Collected") return "sample_collected";
  if (tab === "Cancelled") return "cancelled";
  return tab;
}

// gstRate is passed in so the BILL column shows the real payable total
// (tests − discount + GST) — the same figure the dashboard revenue uses.
function mapOrder(o, gstRate = 0) {
  const { grandTotal } = calcBillTotals({
    testsTotal: Number(o.bill_total) || 0,
    discountType: o.discount_type || "percentage",
    discountValue: Number(o.discount_value) || 0,
    homeVisitFee: 0,
    gstRate,
  });

  return {
    orderId: o.order_no,
    patient: o.patient?.display_name || [o.patient?.first_name, o.patient?.last_name].filter(Boolean).join(" "),
    regNo: o.patient?.patient_number || "",
    tests: o.items_count ?? o.items?.length ?? 0,
    testNames: (o.items || []).map((item) => item.lab_test?.name).filter(Boolean),
    status: statusLabel(o.status),
    date: o.ordered_at
      ? new Date(o.ordered_at).toLocaleString("en-GB", {
          day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit",
        })
      : "",
    bill: Number(grandTotal || 0).toFixed(2),
    rawStatus: o.status,
    items: o.items || [],
    isHomeCollection: Boolean(o.home_collection_id),
  };
}

export default function LabOrders() {
  const location = useLocation();
  const navigate = useNavigate();
  const { toast, showToast, hideToast } = useToast();

  const [searchParams, setSearchParams] = useSearchParams();
  const initialTab = searchParams.get("tab") === "pending" ? "Pending" : "All";
  const initialToday = searchParams.get("today") === "1";

  const [search, setSearch] = useState("");
  const [activeTab, setActiveTab] = useState(initialTab);
  const [isTodayFilter, setIsTodayFilter] = useState(initialToday);
  const [rawOrders, setRawOrders] = useState([]);
  const [gstInfo, setGstInfo] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState(null);
  const [page, setPage] = useState(1);
  const [lastPage, setLastPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [modalOrder, setModalOrder] = useState(null);
  const [cancelledOrder, setCancelledOrder] = useState(null);
  const [refreshKey, setRefreshKey] = useState(0);

  // GST setting — needed so the BILL column matches the payable total.
  useEffect(() => {
    getGstSettingsApi()
      .then((res) => setGstInfo(res.data))
      .catch(() => setGstInfo(null));
  }, []);

  const gstRate = gstInfo?.is_gst_registered ? Number(gstInfo.gst_rate) || 0 : 0;

  // OrderDetail navigates here with { justDeleted: { orderId, patientName } }
  // right after a successful order deletion — same pattern as the justBooked
  // / justCreated toasts elsewhere. Refetch so the removed order actually
  // disappears from the list, and clear the state afterward.
  useEffect(() => {
    if (location.state?.justDeleted) {
      const { orderId, patientName } = location.state.justDeleted;
      showToast(`Order #${orderId} deleted for ${patientName || "patient"}`);
      navigate(location.pathname, { replace: true, state: {} });
      setRefreshKey((k) => k + 1);
    }
  }, [location.state, location.pathname, navigate, showToast]);

  useEffect(() => {
    if (location.state?.justCreated) {
      const { orderId, patientName } = location.state.justCreated;
      showToast(`Order #${orderId} created for ${patientName || "patient"}`);
      navigate(location.pathname, { replace: true, state: {} });
      setRefreshKey((k) => k + 1);
    }
  }, [location.state, location.pathname, navigate, showToast]);

  useEffect(() => {
    let cancelled = false;
    setIsLoading(true);
    setLoadError(null);

    getOrdersApi({
      today: isTodayFilter ? 1 : undefined,
      status: tabToStatus(activeTab),
      q: search,
      page,
      per_page: PER_PAGE,
    })
      .then((res) => {
        if (!cancelled) {
          setRawOrders(res.data || []);
          setLastPage(res.last_page ?? res.meta?.last_page ?? 1);
          setTotal(res.total ?? res.meta?.total ?? 0);
        }
      })
      .catch((err) => {
        if (!cancelled) setLoadError(err.message);
      })
      .finally(() => {
        if (!cancelled) setIsLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [activeTab, isTodayFilter, search, page, refreshKey]);

  // Map after both the orders and the GST rate are known, so the bill
  // updates automatically if the GST setting loads after the list.
  const orders = useMemo(
    () => rawOrders.map((o) => mapOrder(o, gstRate)),
    [rawOrders, gstRate]
  );

  // Reset to page 1 whenever the filter or search changes.
  useEffect(() => {
    setPage(1);
  }, [activeTab, isTodayFilter, search]);

  // Clicking any of All / Pending / Completed drops the "Today" filter and
  // returns to normal tab-driven browsing.
  function handleTabChange(tab) {
    setActiveTab(tab);
    if (isTodayFilter) {
      setIsTodayFilter(false);
      if (searchParams.get("today")) {
        const next = new URLSearchParams(searchParams);
        next.delete("today");
        setSearchParams(next, { replace: true });
      }
    }
  }

  function clearTodayFilter() {
    setIsTodayFilter(false);
    if (searchParams.get("today")) {
      const next = new URLSearchParams(searchParams);
      next.delete("today");
      setSearchParams(next, { replace: true });
    }
  }

  // Pending orders need a "sample collected" confirmation step before
  // opening the order detail / results page. Anything past pending
  // (sample_collected, completed) opens straight through, as before.
  function handleOpenOrder(order) {
    if (order.rawStatus === "pending") {
      setModalOrder(order);
    } else if (order.rawStatus === "cancelled") {
      setCancelledOrder(order);
    } else {
      navigate(`/lab-orders/${order.orderId}`);
    }
  }

  function handleSampleCollected(orderId, patientName) {
    setModalOrder(null);
    navigate(`/lab-orders/${orderId}`, {
      state: { justCollected: { orderId, patientName } },
    });
  }

  const filteredOrders = useMemo(() => orders, [orders]);

  return (
    <div className="space-y-6">
      <LabOrdersHeader />

      <div className="bg-white rounded-xl p-5 shadow-[0_1px_3px_rgba(0,0,0,0.06)] space-y-5">
        <LabOrdersFilters
          search={search}
          onSearchChange={setSearch}
          activeTab={isTodayFilter ? null : activeTab}
          onTabChange={handleTabChange}
        />

        {loadError && (
          <p className="text-sm text-red-500 text-center py-2">{loadError}</p>
        )}

        {isLoading ? (
          <p className="text-sm text-gray-400 text-center py-6">Loading orders…</p>
        ) : (
          <>
            <div className="hidden md:block">
              <LabOrdersTable orders={filteredOrders} onOpen={handleOpenOrder} />
            </div>
            <div className="md:hidden space-y-3">
              {filteredOrders.map((order) => (
                <LabOrderCard key={order.orderId} {...order} onOpen={handleOpenOrder} />
              ))}
            </div>

            {filteredOrders.length === 0 && (
              <p className="text-sm text-gray-400 text-center py-6">
                {isTodayFilter ? "No orders today." : "No orders found."}
              </p>
            )}

            {filteredOrders.length > 0 && lastPage > 1 && (
              <div className="flex items-center justify-between border-t border-gray-100 pt-2 !mt-1">
                <p className="text-xs text-gray-500">
                  Page {page} of {lastPage} · {total} orders
                </p>
                <div className="flex gap-2">
                  <button
                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                    disabled={page <= 1}
                    className="px-2.5 py-1 rounded-lg border border-gray-200 text-xs font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-40 cursor-pointer"
                  >
                    ← Prev
                  </button>
                  <button
                    onClick={() => setPage((p) => Math.min(lastPage, p + 1))}
                    disabled={page >= lastPage}
                    className="px-2.5 py-1 rounded-lg border border-gray-200 text-xs font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-40 cursor-pointer"
                  >
                    Next →
                  </button>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {cancelledOrder && (
        <CancelledOrderModal
          order={cancelledOrder}
          onClose={() => setCancelledOrder(null)}
        />
      )}

      {modalOrder && (
        <SampleCollectionModal
          order={modalOrder}
          onClose={() => setModalOrder(null)}
          onConfirmed={(orderId) => handleSampleCollected(orderId, modalOrder.patient)}
          onCancelled={(orderId) => {
            showToast(`Order #${orderId} cancelled for ${modalOrder.patient || "patient"}`);
            setModalOrder(null);
            setRefreshKey((k) => k + 1);
          }}
        />
      )}

      {toast && <Toast message={toast.message} type={toast.type} onClose={hideToast} />}
    </div>
  );
}