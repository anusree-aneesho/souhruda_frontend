// src/components/LabOrders/OrderDetail/ResultRow.jsx
import { Pencil } from "lucide-react";
import StatusBadge from "../../Dashboard/TodaysOrders/StatusBadge";

export default function ResultRow({ test, result, flag, onResultChange, onEditRange }) {
  // A parameter of a group test (e.g. Haemoglobin under CBC). The group's heading
  // row carries the price, so a parameter shows none of its own.
  const isParameter = test.parentItemId != null;

  return (
    <tr className="group border-b border-gray-100 last:border-0">
      <td className={`py-3 ${isParameter ? "pl-5" : ""}`}>
        <p className="text-sm font-medium text-gray-900">{test.name}</p>
        {!isParameter && <p className="text-xs text-gray-400">{test.category}</p>}
      </td>
      <td className="py-3 text-sm text-gray-500">{test.unit || "-"}</td>
      <td className="py-3 text-sm text-teal-600">
        <div className="flex items-center gap-2">
          <span>{test.range}</span>
          {onEditRange && (
            <button
              type="button"
              onClick={() => onEditRange(test)}
              title="Edit normal range"
              aria-label={`Edit normal range for ${test.name}`}
              className="opacity-0 group-hover:opacity-100 focus:opacity-100 transition-opacity text-gray-400 hover:text-teal-600 cursor-pointer"
            >
              <Pencil size={14} />
            </button>
          )}
        </div>
      </td>
      <td className="py-3">
        <input
          value={result}
          onChange={(e) => onResultChange(test.id, e.target.value)}
          placeholder="Enter result"
          className="w-32 rounded-lg border border-gray-200 px-3 py-1.5 text-sm outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500"
        />
      </td>
      <td className="py-3"><StatusBadge status={flag} /></td>
      <td className="py-3 text-sm">
        {isParameter ? null : test.packageId != null ? (
          <span className="text-teal-600 text-xs font-medium">In package</span>
        ) : (
          <span className="text-gray-900">₹{test.price.toFixed(2)}</span>
        )}
      </td>
    </tr>
  );
}