// src/components/Technicians/Technicians.jsx
import { useState, useEffect, useMemo, useCallback } from "react";
import TechniciansHeader from "./TechniciansHeader";
import TechniciansSearch from "./TechniciansSearch";
import TechniciansTable from "./TechniciansTable/TechniciansTable";
import TechnicianCard from "./TechniciansTable/TechnicianCard";
import CreateTechnicianModal from "./modals/CreateTechnicianModal";
import ConfirmModal from "../Patients/modals/ConfirmModal";
import Toast from "../common/Toast/Toast";
import { useToast } from "../common/Toast/useToast";
import { useAuth } from "../../Context/AuthContext";
import {
  getTechniciansApi,
  createTechnicianApi,
  updateTechnicianApi,
  deleteTechnicianApi,
} from "../../api/api";

// Roles that can only view the technicians list (no add / edit / remove)
const VIEW_ONLY_ROLES = ["lab_assistant", "technician"];

function mapTechnicianFromApi(t) {
  return {
    id: t.id,
    techId: `TECH-${String(t.id).padStart(3, "0")}`,
    name: t.name,
    email: t.email,
    phone: t.phone,
    zone: t.zone,
    branch_id: t.branch_id,
    latitude: t.latitude,
    longitude: t.longitude,
    rating: t.rating,
    status: t.status,
    assignedJobs: t.assignedJobs ?? 0,
    currentStatus: t.currentStatus,
  };
}

export default function Technicians() {
  const { user } = useAuth();

  // Normalise so "Lab Assistant", "lab-assistant" and "lab_assistant" all match
  const role = String(user?.role ?? "")
    .toLowerCase()
    .trim()
    .replace(/[\s-]+/g, "_");

  // Hidden until the user is loaded, and for view-only roles
  const canManage = Boolean(user) && !VIEW_ONLY_ROLES.includes(role);

  const [technicians, setTechnicians] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [modalState, setModalState] = useState(null); // null | { editingTechnician: null | technician }
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [removingTechnician, setRemovingTechnician] = useState(null); // technician pending removal, or null
  const [removeError, setRemoveError] = useState(null);
  const { toast, showToast, hideToast } = useToast();

  const loadTechnicians = useCallback(() => {
    return getTechniciansApi()
      .then((data) => setTechnicians(data.map(mapTechnicianFromApi)))
      .catch((err) => console.error("Failed to load technicians", err));
  }, []);

  useEffect(() => {
    loadTechnicians().finally(() => setLoading(false));
  }, [loadTechnicians]);

  const filteredTechnicians = useMemo(() => {
    return technicians.filter(
      (t) =>
        t.name.toLowerCase().includes(search.toLowerCase()) ||
        t.techId.toLowerCase().includes(search.toLowerCase()) ||
        t.phone.includes(search) ||
        (t.zone ?? "").toLowerCase().includes(search.toLowerCase())
    );
  }, [technicians, search]);

  async function handleSaveTechnician(formData) {
    const isEdit = Boolean(formData.id);
    const payload = {
      name: formData.name,
      email: formData.email,
      phone: formData.phone,
      branch_id: formData.branch_id,
      status: formData.status,
      latitude: formData.latitude,
      longitude: formData.longitude,
    };

    // Rating is only editable (and only sent) on update — new technicians
    // default to 5.0 server-side, and StoreTechnicianRequest doesn't accept it.
    if (isEdit) {
      payload.rating = formData.rating;
    }

    try {
      if (isEdit) {
        await updateTechnicianApi(formData.id, payload);
      } else {
        await createTechnicianApi(payload);
      }

      // Refetch rather than patch local state — guarantees the same order
      // (newest first) and computed fields (assignedJobs, currentStatus)
      // a real page reload would show, instead of drifting out of sync.
      await loadTechnicians();

      showToast(isEdit ? `Rating updated for ${formData.name}` : `${formData.name} added as technician`);
    } catch (err) {
      console.error("Failed to save technician", err);
      alert(err.message || "Failed to save technician. Please check the form and try again.");
      return;
    }

    setModalState(null);
    setShowCreateModal(false);
  }

  function handleRemoveTechnician(tech) {
    if (!canManage) return; // safety net in case the button is ever rendered
    setRemoveError(null);
    setRemovingTechnician(tech);
  }

  async function confirmRemoveTechnician() {
    const tech = removingTechnician;
    if (!tech) return;

    try {
      await deleteTechnicianApi(tech.id);
      setTechnicians((prev) => prev.filter((t) => t.id !== tech.id));
      setRemovingTechnician(null);
      showToast(`${tech.name} removed`);
    } catch (err) {
      console.error("Failed to remove technician", err);
      setRemoveError(err.message || "Something went wrong removing the technician.");
    }
  }

  return (
    <div className="space-y-6">
      <TechniciansHeader
        onAddTechnician={() => setModalState({ editingTechnician: null })}
        onCreateTechnician={() => setShowCreateModal(true)}
        canManage={canManage}
      />

      <div className="bg-white rounded-xl p-5 shadow-[0_1px_3px_rgba(0,0,0,0.06)] space-y-5">
        <TechniciansSearch value={search} onChange={setSearch} />

        {loading ? (
          <p className="text-sm text-gray-400 text-center py-6">Loading technicians...</p>
        ) : (
          <>
            <div className="hidden md:block">
              <TechniciansTable
                technicians={filteredTechnicians}
                onEdit={(t) => setModalState({ editingTechnician: t })}
                onRemove={handleRemoveTechnician}
                canManage={canManage}
              />
            </div>
            <div className="md:hidden space-y-3">
              {filteredTechnicians.map((t) => (
                <TechnicianCard
                  key={t.techId}
                  technician={t}
                  onEdit={(tech) => setModalState({ editingTechnician: tech })}
                  onRemove={handleRemoveTechnician}
                  canManage={canManage}
                />
              ))}
            </div>

            {filteredTechnicians.length === 0 && (
              <p className="text-sm text-gray-400 text-center py-6">No technicians found.</p>
            )}
          </>
        )}
      </div>

      {canManage && modalState && (
        <CreateTechnicianModal
          editingTechnician={modalState.editingTechnician}
          onClose={() => setModalState(null)}
          onSave={handleSaveTechnician}
        />
      )}

      {canManage && showCreateModal && (
        <CreateTechnicianModal
          onClose={() => setShowCreateModal(false)}
          onSave={handleSaveTechnician}
        />
      )}

      {canManage && removingTechnician && (
        <ConfirmModal
          title="Remove Technician"
          message={`Remove "${removingTechnician.name}"? This can't be undone.${
            removeError ? `\n\n${removeError}` : ""
          }`}
          confirmLabel="Remove Technician"
          cancelLabel="Cancel"
          danger
          onConfirm={confirmRemoveTechnician}
          onClose={() => {
            setRemovingTechnician(null);
            setRemoveError(null);
          }}
        />
      )}

      {toast && <Toast message={toast.message} type={toast.type} onClose={hideToast} />}
    </div>
  );
}