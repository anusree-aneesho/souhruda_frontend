// src/components/common/NewOrderModal/NewOrderModal.jsx
import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import ModalShell from "../../common/Modal/ModalShell";
import StepProgressBar from "./StepProgressBar";
import PatientStep, { ReferredByField, withTitle } from "./steps/PatientStep";
import SelectTestsStep from "./steps/SelectTestsStep";
import ConfirmStep from "./steps/ConfirmStep";
import AddressSlotStep from "./steps/AddressSlotStep";
import PaymentStep from "./steps/PaymentStep";
import { useOrderModal } from "../../../Context/OrderModalContext";
import EditPatientModal from "../../Patients/modals/EditPatientModal";
import QuickAddDoctorModal from "./QuickAddDoctorModal";
import BillModal from "../../LabOrders/Report/BillModal";
import Toast from "../../common/Toast/Toast";
import {
  getPatientsApi,
  getPatientApi,
  createPatientApi,
  updatePatientApi,
  createHomeCollectionRequestApi,
  quoteHomeCollectionApi,
  createOrderApi,
  getTestPackages,
  getDoctorsApi,
  getPatientFollowUpRemindersApi,
  getLabTests,
} from "../../../api/api";
import { computeOrderPricing } from "../../../utils/orderPricing";

function mapPatient(p) {
  return {
    id: p.id,
    regNo: p.patient_number,
    name: withTitle(p.title, p.full_name),
    age: p.age,
    gender: p.gender,
    contact: p.phone,
  };
}

function mapPatientForEdit(p) {
  return {
    id: p.id,
    regNo: p.patient_number,
    title: p.title,
    name: p.full_name,
    date_of_birth: p.date_of_birth,
    gender: p.gender,
    isPregnant: p.is_pregnant,
    contact: p.phone,
    email: p.email,
    address: p.address,
  };
}

function mapLabTestForOrder(t) {
  return {
    id: t.id,
    name: t.name,
    code: t.code || "",
    unit: t.unit || "",
    range: t.range_text || t.range_raw || "",
    price: Number(t.price) || 0,
    categoryId: t.category_id,
    category: t.category_id,
  };
}

function ageFromDOB(dob) {
  if (!dob) return "-";
  const birthDate = new Date(dob);
  if (isNaN(birthDate.getTime())) return "-";

  const today = new Date();
  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();

  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }

  return age;
}

const emptyNewPatient = {
  title: "",
  name: "",
  dateOfBirth: "",
  gender: "Male",
  contact: "",
  isPregnant: false,
  email: "",
  address: "",
};

function buildNewPatientPayload(newPatientData) {
  const [firstName, ...rest] = newPatientData.name.trim().split(" ");
  const lastName = rest.join(" ") || null;

  return {
    title: newPatientData.title || null,
    first_name: firstName,
    last_name: lastName,
    date_of_birth: newPatientData.dateOfBirth,
    gender: newPatientData.gender?.toLowerCase(),
    phone: newPatientData.contact || null,
    email: newPatientData.email || null,
    address: newPatientData.address || null,
    is_pregnant: newPatientData.gender === "Female" ? newPatientData.isPregnant : false,
  };
}

const REMINDER_WINDOW_DAYS = 5;

function isReminderDueSoon(dueDate) {
  const due = new Date(dueDate);
  if (isNaN(due.getTime())) return false;

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  due.setHours(0, 0, 0, 0);

  const daysLeft = Math.round((due - today) / (1000 * 60 * 60 * 24));
  return daysLeft <= REMINDER_WINDOW_DAYS;
}

function FlowTypeToggle({ value, onChange }) {
  const options = [
    { key: "order", label: "Lab Orders" },
    { key: "homeCollection", label: "Home Collection" },
  ];

  return (
    <div role="radiogroup" aria-label="Order type" className="flex gap-2">
      {options.map((o) => {
        const active = value === o.key;
        return (
          <button
            key={o.key}
            type="button"
            role="radio"
            aria-checked={active}
            onClick={() => onChange(o.key)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors cursor-pointer ${
              active
                ? "bg-teal-600 text-white"
                : "bg-gray-100 text-gray-500 hover:bg-gray-200"
            }`}
          >
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

export default function NewOrderModal() {
  const { isOpen, close, flowType, setFlowType, presetPatientRegNo } = useOrderModal();
  const navigate = useNavigate();
  const isHomeCollection = flowType === "homeCollection";
  const totalSteps = isHomeCollection ? 4 : 3;
  const skipPatientStep = Boolean(presetPatientRegNo);

  const [step, setStep] = useState(1);
  const [patientType, setPatientType] = useState("existing");
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [newPatientData, setNewPatientData] = useState(emptyNewPatient);
  const [createdPatient, setCreatedPatient] = useState(null);
  const [activeCategory, setActiveCategory] = useState(null);
  const [selectedTests, setSelectedTests] = useState([]);
  const [appliedPackageIds, setAppliedPackageIds] = useState([]);
  const [paymentDone, setPaymentDone] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState(null);
  const [isCreatingPatient, setIsCreatingPatient] = useState(false);

  const [editingPatient, setEditingPatient] = useState(null);
  const [isLoadingPatientToEdit, setIsLoadingPatientToEdit] = useState(false);

  const [doctors, setDoctors] = useState([]);
  const [packages, setPackages] = useState([]);
  const [referredBy, setReferredBy] = useState("");
  const [referredByTouched, setReferredByTouched] = useState(false);
  const [showAddDoctor, setShowAddDoctor] = useState(false);

  const [patientReminders, setPatientReminders] = useState([]);
  // Several follow-ups can be linked to one order
  const [selectedReminderIds, setSelectedReminderIds] = useState([]);

  const closeToast = useCallback(() => setToast(null), []);
  // Success toast (e.g. "Dr. X added successfully")
  const [toast, setToast] = useState(null);

  // Discount chosen on the Confirm / Payment step
  const [discount, setDiscount] = useState({ type: "percentage", value: 0 });

  // Set after a paid order / booking is created, so the real bill can be shown
  const [billData, setBillData] = useState(null);

  async function handleEditSelectedPatient() {
    if (!selectedPatient?.id) return;
    setIsLoadingPatientToEdit(true);
    try {
      const res = await getPatientApi(selectedPatient.id);
      setEditingPatient(mapPatientForEdit(res.data));
    } catch (err) {
      setSubmitError(err.message || "Couldn't load patient details.");
    } finally {
      setIsLoadingPatientToEdit(false);
    }
  }

  async function handleSaveEditedPatient(id, formData) {
    const [first_name, ...rest] = formData.name.trim().split(" ");
    const last_name = rest.join(" ") || null;

    try {
      await updatePatientApi(id, {
        title: formData.title || null,
        first_name,
        last_name,
        date_of_birth: formData.date_of_birth,
        gender: formData.gender.toLowerCase(),
        is_pregnant: formData.gender === "Female" ? formData.isPregnant : null,
        phone: formData.contact,
        email: formData.email || null,
        address: formData.address || null,
      });

      const res = await getPatientApi(id);
      setSelectedPatient(mapPatient(res.data));
      setEditingPatient(null);
    } catch (err) {
      setSubmitError(err.message || "Couldn't update the patient. Please try again.");
      setEditingPatient(null);
    }
  }

  // Called after the quick-add form saves a doctor. The dropdown options use
  // the value `Dr. ${name}`, so the selected value must use the same format.
  function handleDoctorCreated(doctor) {
    if (!doctor?.name) return;

    setDoctors((prev) =>
      doctor.id && prev.some((d) => d.id === doctor.id) ? prev : [...prev, doctor]
    );
    setReferredBy(`Dr. ${doctor.name}`);
    setReferredByTouched(false);
    setShowAddDoctor(false);
    setToast(`Dr. ${doctor.name} added successfully`);
  }

  useEffect(() => {
    if (isOpen && skipPatientStep) {
      setPatientType("existing");
      setStep(2);

      let cancelled = false;
      (async () => {
        try {
          const res = await getPatientsApi(presetPatientRegNo);
          const match = (res.data || []).find((p) => p.patient_number === presetPatientRegNo);
          if (!cancelled && match) setSelectedPatient(mapPatient(match));
        } catch (err) {
          console.error("Failed to load patient:", err.message);
        }
      })();

      return () => {
        cancelled = true;
      };
    } else if (isOpen) {
      setStep(1);
    }
  }, [isOpen, skipPatientStep, presetPatientRegNo]);

  useEffect(() => {
    if (!isOpen) return;
    let cancelled = false;
    (async () => {
      try {
        const res = await getDoctorsApi();
        if (!cancelled) setDoctors(res.data || []);
      } catch (err) {
        console.error("Failed to load doctors:", err.message);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    let cancelled = false;
    (async () => {
      try {
        const res = await getTestPackages();
        if (!cancelled) setPackages((res.data || []).filter((p) => p.is_active));
      } catch (err) {
        console.error("Failed to load test packages:", err.message);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [isOpen]);

  useEffect(() => {
    // Linked reminders belong to the previous patient, so clear them whenever
    // the patient changes.
    setSelectedReminderIds([]);

    const patientId = patientType === "new" ? createdPatient?.id : selectedPatient?.id;
    if (!patientId) {
      setPatientReminders([]);
      return;
    }
    let cancelled = false;
    getPatientFollowUpRemindersApi(patientId)
      .then((res) => {
        if (cancelled) return;
        setPatientReminders(
          (res.data || []).filter(
            (r) =>
              ["pending", "overdue"].includes(r.status) &&
              isReminderDueSoon(r.due_date)
          )
        );
      })
      .catch((err) => {
        console.error("Failed to load follow-up reminders:", err.message);
      });
    return () => {
      cancelled = true;
    };
  }, [patientType, selectedPatient?.id, createdPatient?.id]);

  // If a test is unticked in the list, unlink any reminder that depended on it,
  // so an order can never claim to complete a follow-up for a test it lacks.
  useEffect(() => {
    if (selectedReminderIds.length === 0) return;
    const stillValid = selectedReminderIds.filter((id) => {
      const r = patientReminders.find((x) => x.id === id);
      return r && selectedTests.some((t) => t.id === r.lab_test_id);
    });
    if (stillValid.length !== selectedReminderIds.length) {
      setSelectedReminderIds(stillValid);
    }
  }, [selectedTests, patientReminders, selectedReminderIds]);

  const [address, setAddress] = useState("");
  const [pinnedLocation, setPinnedLocation] = useState(null);
  const [isLocating, setIsLocating] = useState(false);
  const [preferredDate, setPreferredDate] = useState("");
  const [timeSlot, setTimeSlot] = useState("Morning · 7–9 AM");
  // Default is "Cash". Shared by Home Collection (PaymentStep) and Lab Orders (ConfirmStep).
  const [paymentMethod, setPaymentMethod] = useState("Cash");
  const [isBooking, setIsBooking] = useState(false);
  const [bookingError, setBookingError] = useState("");

  function resetAndClose() {
    setStep(1);
    setPatientType("existing");
    setSelectedPatient(null);
    setNewPatientData(emptyNewPatient);
    setCreatedPatient(null);
    setActiveCategory(null);
    setSelectedTests([]);
    setAppliedPackageIds([]);
    setPaymentDone(false);
    setDiscount({ type: "percentage", value: 0 });
    setBillData(null);
    setAddress("");
    setPinnedLocation(null);
    setIsLocating(false);
    setPreferredDate("");
    setTimeSlot("Morning · 7–9 AM");
    setPaymentMethod("Cash");
    setIsBooking(false);
    setBookingError("");
    setIsSubmitting(false);
    setSubmitError(null);
    setIsCreatingPatient(false);
    setEditingPatient(null);
    setReferredBy("");
    setReferredByTouched(false);
    setShowAddDoctor(false);
    setPatientReminders([]);
    setSelectedReminderIds([]);
    setToast(null);
    close();
  }

  // Closing the bill goes to Home Collection or Lab Orders,
  // depending on which flow created it.
  function handleBillClose() {
    const info = billData;
    resetAndClose();
    if (info?.flow === "home") {
      navigate("/home-collection", { state: { justBooked: info.created } });
      return;
    }
    navigate("/lab-orders", {
      state: {
        justCreated: {
          orderId: info?.orderId,
          patientName: info?.patient?.first_name,
        },
      },
    });
  }

  function toggleTest(test) {
    setSelectedTests((prev) =>
      prev.some((t) => t.id === test.id) ? prev.filter((t) => t.id !== test.id) : [...prev, test]
    );
  }

  // Clicking a follow-up in the yellow card adds its test to the order (if it
  // isn't already there) and links the reminder to the order.
  async function handleSelectReminder(reminder) {
    // Clicking an already-linked follow-up unlinks it (the test stays in the order)
    if (selectedReminderIds.includes(reminder.id)) {
      setSelectedReminderIds((prev) => prev.filter((id) => id !== reminder.id));
      return;
    }

    // Test already in the order: just link
    if (selectedTests.some((t) => t.id === reminder.lab_test_id)) {
      setSelectedReminderIds((prev) => [...prev, reminder.id]);
      return;
    }

    setSubmitError(null);
    try {
      const res = await getLabTests();
      const labTest = (res.data || []).find((t) => t.id === reminder.lab_test_id);
      if (!labTest) {
        setSubmitError("That test is no longer available.");
        return;
      }

      // Set together so the "unlink if test missing" effect never fires in between
      setSelectedTests((prev) =>
        prev.some((t) => t.id === labTest.id) ? prev : [...prev, mapLabTestForOrder(labTest)]
      );
      setActiveCategory(labTest.category_id ?? null);
      setSelectedReminderIds((prev) => (prev.includes(reminder.id) ? prev : [...prev, reminder.id]));
    } catch (err) {
      setSubmitError(err.message || "Couldn't add the follow-up test.");
    }
  }

  function applyPackageId(packageId) {
    setAppliedPackageIds((prev) => (prev.includes(packageId) ? prev : [...prev, packageId]));
  }

  function removePackageIds(packageIds) {
    setAppliedPackageIds((prev) => prev.filter((id) => !packageIds.includes(id)));
  }

  async function pinAt(lat, lng) {
    const location = { lat: Number(lat.toFixed(6)), lng: Number(lng.toFixed(6)) };
    try {
      const quote = await quoteHomeCollectionApi(location.lat, location.lng);
      setPinnedLocation({
        ...location,
        distanceKm: quote.distance_km,
        collectionCharge: Number(quote.collection_charge),
        feeBreakdown: quote.fee_breakdown,
        maxRadiusKm: quote.max_radius_km,
        withinRadius: quote.within_radius,
      });
    } catch (err) {
      setPinnedLocation(null);
      setBookingError(err.message || "Couldn't calculate the home visit fee for this location.");
    } finally {
      setIsLocating(false);
    }
  }

  function handlePinLocation() {
    setBookingError("");
    setPinnedLocation(null);

    if (!navigator.geolocation) {
      setBookingError("This browser doesn't support location access.");
      return;
    }

    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => pinAt(pos.coords.latitude, pos.coords.longitude),
      (err) => {
        setIsLocating(false);
        setBookingError(
          err.code === 1
            ? "Location permission was blocked. Allow location access for this site and try again."
            : "Couldn't get the location. Please try again."
        );
      },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  }

  const flowLabel = isHomeCollection ? "Home Collection" : "New Order";
  const stepTitles = isHomeCollection
    ? {
        1: `${flowLabel} — Patient`,
        2: `${flowLabel} — Select Tests`,
        3: `${flowLabel} — Address & Slot`,
        4: `${flowLabel} — Payment`,
      }
    : {
        1: `${flowLabel} — Patient`,
        2: `${flowLabel} — Select Tests`,
        3: "Confirm Order",
      };

  const nextButtonLabels = isHomeCollection
    ? { 1: "Next: Select Tests →", 2: "Next: Address & Slot →", 3: "Next: Payment →" }
    : { 1: "Next: Select Tests →", 2: "Next: Confirm →" };

  const currentPatient =
    patientType === "existing"
      ? selectedPatient
      : createdPatient
      ? createdPatient
      : {
          name: newPatientData.name || "New Patient",
          age: ageFromDOB(newPatientData.dateOfBirth),
          gender: newPatientData.gender,
          regNo: "NEW",
        };

  async function handleNext() {
    if ((step === 1 || (step === 2 && skipPatientStep)) && !referredBy) {
      setReferredByTouched(true);
      return;
    }
    if (step === 1 && patientType === "new" && !createdPatient) {
      if (!newPatientData.name.trim()) {
        setSubmitError("Please enter the patient's name.");
        return;
      }
      if (!newPatientData.dateOfBirth) {
        setSubmitError("Please enter the patient's date of birth.");
        return;
      }

      setIsCreatingPatient(true);
      setSubmitError(null);

      try {
        const res = await createPatientApi(buildNewPatientPayload(newPatientData));
        setCreatedPatient(mapPatient(res.data));
        setStep((s) => s + 1);
      } catch (err) {
        setSubmitError(err.message || "Couldn't save the patient. Please try again.");
      } finally {
        setIsCreatingPatient(false);
      }
      return;
    }

    // Entering the Payment step starts clean (discount off, not paid),
    // matching PaymentStep's own fresh local state.
    if (isHomeCollection && step === 3) {
      setDiscount({ type: "percentage", value: 0 });
      setPaymentDone(false);
    }

    setStep((s) => s + 1);
  }

  async function handleCreateOrder() {
    setIsSubmitting(true);
    setSubmitError(null);

    try {
      const patientId = patientType === "new" ? createdPatient?.id : selectedPatient?.id;

      if (!patientId) {
        setSubmitError("No patient selected. Please go back and select or add a patient.");
        setIsSubmitting(false);
        return;
      }

      const pricing = computeOrderPricing(selectedTests, packages, appliedPackageIds);
      const { appliedPackages } = pricing;

      const payload = {
        patient_id: patientId,
        tests: selectedTests.map((t) => ({
          lab_test_id: t.id,
        })),
        package_ids: appliedPackages.map((p) => p.id),
        referred_by: referredBy,
        payment_received: paymentDone,
        // ADDED: cash | upi | card (only sent when payment is received)
        payment_mode: paymentDone ? paymentMethod.toLowerCase() : null,
        follow_up_reminder_ids: selectedReminderIds,
        discount_type: discount.type,
        discount_value: Number(discount.value) || 0,
      };

      const res = await createOrderApi(payload);
      const order = res.data;

      // Paid at creation: keep the modal open and show the real bill, now that
      // the order exists in the database (so print / PDF download both work).
      if (paymentDone) {
        const billTests = [
          ...pricing.appliedPackages.flatMap((pkg) =>
            pkg.tests.map((t) => ({
              ...t,
              package_id: pkg.id,
              package_name: pkg.name,
              package_price: pkg.price,
            }))
          ),
          ...pricing.individualTests,
        ];

        setBillData({
          flow: "order",
          orderId: order.order_no,
          patient: { ...currentPatient, phone: currentPatient?.contact },
          tests: billTests,
          billTotal: pricing.total,
          homeVisitFee: 0,
          discountType: discount.type,
          discountValue: discount.value,
          referredBy,
        });
        setIsSubmitting(false);
        return;
      }

      resetAndClose();
      navigate("/lab-orders", {
        state: { justCreated: { orderId: order.order_no, patientName: currentPatient?.first_name } },
      });
    } catch (err) {
      setSubmitError(err.message);
      setIsSubmitting(false);
    }
  }

  async function handleConfirmBooking() {
    if (!pinnedLocation) {
      setBookingError("Please pin the collection location before confirming.");
      return;
    }

    if (!pinnedLocation.withinRadius) {
      setBookingError(`This location is outside our ${pinnedLocation.maxRadiusKm} km home collection area.`);
      return;
    }

    setIsBooking(true);
    setBookingError("");

    try {
      const patientId = patientType === "new" ? createdPatient?.id : selectedPatient?.id;

      if (!patientId) {
        setBookingError("Please select or add a patient before confirming.");
        setIsBooking(false);
        return;
      }

      const pricing = computeOrderPricing(selectedTests, packages, appliedPackageIds);
      const { appliedPackages } = pricing;

      const payload = {
        patient_id: patientId,
        tests: selectedTests.map((t) => t.id),
        package_ids: appliedPackages.map((p) => p.id),
        address_line: address,
        latitude: pinnedLocation.lat,
        longitude: pinnedLocation.lng,
        slot_date: preferredDate,
        slot_label: timeSlot,
        payment_mode: paymentMethod.toLowerCase(),
        referred_by: referredBy,
        // The backend must accept/save these for the saved bill to match
        payment_received: paymentDone,
        discount_type: discount.type,
        discount_value: Number(discount.value) || 0,
      };

      const created = await createHomeCollectionRequestApi(payload);

      // "Payment already received" ticked -> show the bill instead of
      // leaving straight away.
      if (paymentDone) {
        const billTests = [
          ...pricing.appliedPackages.flatMap((pkg) =>
            pkg.tests.map((t) => ({
              ...t,
              packageId: pkg.id,
              packageName: pkg.name,
              packagePrice: pkg.price,
            }))
          ),
          ...pricing.individualTests,
        ];

        // ASSUMPTION: the response carries the order number. If your API uses
        // a different field, change this line.
        const billOrderId =
          created?.order_no ?? created?.data?.order_no ?? created?.order?.order_no ?? created?.id;

        setBillData({
          flow: "home",
          created,
          orderId: billOrderId,
          patient: { ...currentPatient, phone: currentPatient?.contact },
          tests: billTests,
          billTotal: pricing.total,
          homeVisitFee: pinnedLocation.collectionCharge,
          discountType: discount.type,
          discountValue: discount.value,
          referredBy,
        });
        setIsBooking(false);
        return;
      }

      resetAndClose();
      navigate("/home-collection", { state: { justBooked: created } });
    } catch (err) {
      setIsBooking(false);
      setBookingError(err.message || "Couldn't create the booking. Please try again.");
    }
  }

  const isNextDisabled =
    (step === 1 && patientType === "existing" && !selectedPatient) ||
    (step === 1 && patientType === "new" && (!newPatientData.name.trim() || !newPatientData.dateOfBirth)) ||
    (step === 1 && !referredBy) ||
    (step === 1 && isCreatingPatient) ||
    (step === 2 && skipPatientStep && !referredBy) ||
    (step === 2 && (selectedTests.length === 0 || !currentPatient)) ||
    (isHomeCollection && step === 3 && (!address.trim() || !preferredDate || !pinnedLocation || !pinnedLocation.withinRadius));

  if (!isOpen) return null;

  // A paid order / booking was just created: show its real bill
  if (billData) {
    return (
      <BillModal
        orderId={billData.orderId}
        patient={billData.patient}
        tests={billData.tests}
        billTotal={billData.billTotal}
        homeVisitFee={billData.homeVisitFee ?? 0}
        discountType={billData.discountType}
        discountValue={billData.discountValue}
        paymentDone={true}
        referredBy={billData.referredBy}
        onClose={handleBillClose}
      />
    );
  }

  return (
    <>
      <ModalShell title={stepTitles[step]} onClose={resetAndClose} maxWidth="max-w-xl">
        <StepProgressBar currentStep={step} totalSteps={totalSteps} />

        {step === 2 && patientReminders.length > 0 && (
          <div className="mx-6 mt-4 rounded-lg border border-amber-200 bg-amber-50 p-3">
            <p className="text-xs font-medium text-amber-800 mb-2">
              Pending follow-up{patientReminders.length > 1 ? "s" : ""} — click to add the test to this order:
            </p>
            <div className="space-y-1">
              {patientReminders.map((r) => {
                const linked = selectedReminderIds.includes(r.id);
                return (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => handleSelectReminder(r)}
                    className={`w-full flex items-center gap-2 text-left text-sm rounded-md px-2 py-1.5 transition-colors cursor-pointer ${
                      linked ? "bg-amber-100 text-amber-900 font-medium" : "text-amber-900 hover:bg-amber-100/60"
                    }`}
                  >
                    <span
                      className={`h-4 w-4 shrink-0 rounded border flex items-center justify-center text-[10px] text-white ${
                        linked ? "border-amber-600 bg-amber-600" : "border-amber-400"
                      }`}
                    >
                      {linked && "✓"}
                    </span>
                    <span>
                      {r.lab_test?.name} — due{" "}
                      {new Date(r.due_date).toLocaleDateString("en-GB", {
                        day: "2-digit", month: "short", year: "numeric",
                      })}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {step === 1 && (
          <PatientStep
            patientType={patientType}
            onPatientTypeChange={setPatientType}
            selectedPatient={selectedPatient}
            onSelectPatient={setSelectedPatient}
            newPatientData={newPatientData}
            onNewPatientChange={(field, value) => setNewPatientData((prev) => ({ ...prev, [field]: value }))}
            onEditSelectedPatient={handleEditSelectedPatient}
            isLoadingPatientToEdit={isLoadingPatientToEdit}
            doctors={doctors}
            referredBy={referredBy}
            onReferredByChange={(val) => {
              setReferredBy(val);
              if (val) setReferredByTouched(false);
            }}
            referredByError={referredByTouched && !referredBy}
            onAddDoctor={() => setShowAddDoctor(true)}
          />
        )}

        {step === 2 && skipPatientStep && (
          <div className="px-6 pt-5 space-y-4">
            <FlowTypeToggle value={flowType} onChange={setFlowType} />
            <ReferredByField
              doctors={doctors}
              referredBy={referredBy}
              onReferredByChange={(val) => {
                setReferredBy(val);
                if (val) setReferredByTouched(false);
              }}
              referredByError={referredByTouched && !referredBy}
              onAddDoctor={() => setShowAddDoctor(true)}
            />
          </div>
        )}

        {step === 2 && (
          <SelectTestsStep
            activeCategory={activeCategory}
            onCategoryChange={setActiveCategory}
            selectedTests={selectedTests}
            onToggleTest={toggleTest}
            packages={packages}
            appliedPackageIds={appliedPackageIds}
            onApplyPackageId={applyPackageId}
            onRemovePackageIds={removePackageIds}
          />
        )}

        {step === 3 && isHomeCollection && (
          <AddressSlotStep
            address={address}
            onAddressChange={setAddress}
            pinnedLocation={pinnedLocation}
            onPinLocation={handlePinLocation}
            isLocating={isLocating}
            locationError={bookingError}
            preferredDate={preferredDate}
            onPreferredDateChange={setPreferredDate}
            timeSlot={timeSlot}
            onTimeSlotChange={setTimeSlot}
          />
        )}
        {step === 3 && !isHomeCollection && (
          <ConfirmStep
            patient={currentPatient}
            selectedTests={selectedTests}
            packages={packages}
            appliedPackageIds={appliedPackageIds}
            paymentDone={paymentDone}
            onPaymentDoneChange={setPaymentDone}
            discount={discount}
            onDiscountChange={setDiscount}
            paymentMethod={paymentMethod}              // ADDED
            onPaymentMethodChange={setPaymentMethod}   // ADDED
          />
        )}

        {step === 4 && isHomeCollection && (
          <>
            <PaymentStep
              selectedTests={selectedTests}
              packages={packages}
              appliedPackageIds={appliedPackageIds}
              collectionCharge={pinnedLocation?.collectionCharge ?? 0}
              feeBreakdown={pinnedLocation?.feeBreakdown}
              paymentMethod={paymentMethod}
              onPaymentMethodChange={setPaymentMethod}
              onDiscountChange={setDiscount}
              onPaymentReceivedChange={setPaymentDone}
            />
            {bookingError && (
              <p className="px-6 text-sm text-red-600">{bookingError}</p>
            )}
          </>
        )}

        <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-gray-100">
          {submitError && (
            <p className="text-sm text-red-500 mr-auto">{submitError}</p>
          )}

          {step === 1 || (skipPatientStep && step === 2) ? (
            <button
              onClick={resetAndClose}
              disabled={isSubmitting}
              className="px-4 py-2.5 rounded-lg border border-gray-200 text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 cursor-pointer"
            >
              Cancel
            </button>
          ) : (
            <button
              onClick={() => setStep((s) => s - 1)}
              disabled={isSubmitting || isBooking}
              className="px-4 py-2.5 rounded-lg border border-gray-200 text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 cursor-pointer"
            >
              ← Back
            </button>
          )}

          {step < totalSteps ? (
            <button
              onClick={handleNext}
              disabled={isNextDisabled || isSubmitting || isCreatingPatient}
              className="px-4 py-2.5 rounded-lg bg-teal-600 text-sm font-medium text-white hover:bg-teal-700 disabled:opacity-40 cursor-pointer"
            >
              {isCreatingPatient ? "Saving patient…" : nextButtonLabels[step]}
            </button>
          ) : (
            <button
              onClick={isHomeCollection ? handleConfirmBooking : handleCreateOrder}
              disabled={isSubmitting || isBooking}
              className="px-4 py-2.5 rounded-lg bg-teal-600 text-sm font-medium text-white hover:bg-teal-700 disabled:opacity-40 cursor-pointer"
            >
              {isSubmitting || isBooking
                ? "Creating…"
                : isHomeCollection
                ? "Confirm Booking"
                : "Create Order"}
            </button>
          )}
        </div>
      </ModalShell>

      {editingPatient && (
        <EditPatientModal
          patient={editingPatient}
          onClose={() => setEditingPatient(null)}
          onSave={handleSaveEditedPatient}
        />
      )}

      {showAddDoctor && (
        <QuickAddDoctorModal
          onClose={() => setShowAddDoctor(false)}
          onCreated={handleDoctorCreated}
        />
      )}

      {toast && (
        <Toast message={toast} type="success" duration={2500} onClose={closeToast} />
      )}
    </>
  );
}